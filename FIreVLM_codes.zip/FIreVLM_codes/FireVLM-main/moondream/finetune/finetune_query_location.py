import torch
import torch.nn as nn
from torch.utils.data import Dataset
import math
from safetensors.torch import save_file

from tqdm import tqdm
from datasets import load_dataset
from bitsandbytes.optim import AdamW8bit
import wandb
wandb.init(mode="offline")
from moondream.torch.weights import load_weights_into_model
from moondream.torch.moondream import MoondreamModel, MoondreamConfig, text_encoder
from moondream.torch.text import _produce_hidden, _lm_head, TextConfig

import os
import json
from PIL import Image

# This is a intended to be a basic starting point for fine-tuning the text encoder.
# Your optimal hyperparams and data may be different.
MODEL_PATH = "../FireVLM/FireVLM-main/models/model.safetensors"
# Your data should end with the eos token. Here is the textual representation.
ANSWER_EOS = "<|endoftext|>"
LR = 3e-6
EPOCHS = 15
GRAD_ACCUM_STEPS = 128


def lr_schedule(step, max_steps):
    x = step / max_steps
    if x < 0.1:
        return 0.1 * LR + 0.9 * LR * x / 0.1
    else:
        return 0.1 * LR + 0.9 * LR * (1 + math.cos(math.pi * (x - 0.1))) / 2


def text_loss(
    inputs_embeds: torch.Tensor, w: nn.Module, labels: torch.Tensor, config: TextConfig
):
    _, q_len, _ = inputs_embeds.shape
    hidden_BTC = _produce_hidden(inputs_embeds, w, config)
    lm_logits = _lm_head(hidden_BTC, w)

    loss = None
    if labels is not None:
        _, _, l_len = labels.shape
        shift_index = (q_len - l_len) - 1
        shifted_logits = lm_logits[..., shift_index:-1, :].contiguous()
        shifted_labels = labels.contiguous()
        loss = nn.CrossEntropyLoss()(
            shifted_logits.view(-1, shifted_logits.size(-1)),
            shifted_labels.view(-1),
        )
    return loss

class RoboflowDataset(Dataset):
    def __init__(self, dataset_path, split):
        self.split = split
        self.dataset_path = dataset_path
        self.dataset = self.load_coco_dataset(f"{dataset_path}/{split}/_annotations.coco.json")

    def load_coco_dataset(self, json_file):
        with open(json_file, 'r') as f:
            data = json.load(f)
        image_to_annotations = {}
        for annotation in data.get('annotations', []):
            image_id = annotation['image_id']
            if image_id not in image_to_annotations:
                image_to_annotations[image_id] = []
            image_to_annotations[image_id].append(annotation)
        category_id_to_name = {cat['id']: cat['name'] for cat in data['categories']}
        dataset = []
        for image_info in data['images']:
            image_id = image_info['id']
            annotations = image_to_annotations.get(image_id, [])
            dataset.append({
                'image_info': image_info,
                'annotations': annotations,
                'category_id_to_name': category_id_to_name
            })
        return dataset

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        data = self.dataset[idx]
        image_info = data['image_info']
        annotations = data['annotations']
        category_id_to_name = data['category_id_to_name']
        image_path = os.path.join(self.dataset_path, self.split, image_info['file_name'])
        image = Image.open(image_path).convert('RGB')
        formatted_annotations = [
            {
                "category": category_id_to_name[annotation['category_id']],
                "bbox": annotation['bbox']
            }
            for annotation in annotations
        ]
        answer = json.dumps(formatted_annotations, indent=2)
        return {
            "image": image,
            "qa": {
                    "question": "\n\nWhere are the fires located in the image? Please provide the answer in JSON format. \n\nAnswer:",
                    "answer":f"{answer}{ANSWER_EOS}",
            },
        }

def main():
    if torch.cuda.is_available():
        torch.set_default_device("cuda:1")
    elif torch.backends.mps.is_available():
        torch.set_default_device("mps")

    wandb.init(
        project="moondream-ft",
        config={
            "EPOCHS": EPOCHS,
            "GRAD_ACCUM_STEPS": GRAD_ACCUM_STEPS,
            "LR": LR,
        },
    )

    config = MoondreamConfig()
    model = MoondreamModel(config)
    load_weights_into_model(MODEL_PATH, model)

    optimizer = AdamW8bit(
        [
            {"params": model.text.parameters()},
        ],
        lr=LR,
        betas=(0.9, 0.95),
        eps=1e-6,
    )

    dataset = RoboflowDataset(
    dataset_path="../Fire Dettection.v2i.coco",
    split="train"
)
    sample = dataset[0]
    # print("Image:", sample["image"].shape)
    print("QA:", sample["qa"])

    total_steps = EPOCHS * len(dataset) // GRAD_ACCUM_STEPS
    pbar = tqdm(total=total_steps)

    i = 0
    for epoch in range(EPOCHS):
        for sample in dataset:
            i += 1
            with torch.no_grad():
                img_emb = model._run_vision_encoder(sample["image"])
            bos_emb = text_encoder(
                torch.tensor([[model.config.tokenizer.bos_id]], device=model.device),
                model.text,
            )
            question_tokens = model.tokenizer.encode(sample["qa"]["question"])
            question_emb = text_encoder(
                torch.tensor([[question_tokens]], device=model.device),
                model.text,
            ).squeeze(0)
            answer_tokens = model.tokenizer.encode(sample["qa"]["answer"])
            answer_emb = text_encoder(
                torch.tensor([[answer_tokens]], device=model.device),
                model.text,
            ).squeeze(0)
            inputs_embeds = torch.cat(
                [bos_emb, img_emb[None], question_emb, answer_emb], dim=1
            )
            loss = text_loss(
                inputs_embeds=inputs_embeds,
                w=model.text,
                labels=torch.tensor([[answer_tokens]], device=model.device),
                config=config.text,
            )

            loss.backward()

            if i % GRAD_ACCUM_STEPS == 0:
                optimizer.step()
                optimizer.zero_grad()

                lr = lr_schedule(i / GRAD_ACCUM_STEPS, total_steps)
                for param_group in optimizer.param_groups:
                    param_group["lr"] = lr
                pbar.set_postfix({"step": i // GRAD_ACCUM_STEPS, "loss": loss.item()})
                pbar.update(1)
                wandb.log(
                    {"loss/train": loss.item(), "lr": optimizer.param_groups[0]["lr"]}
                )
    wandb.finish()
    # Add save path: ex. home/model.safetensors
    save_file(
        model.state_dict(),
        "../FireVLM/FireVLM-main/models/moondream_text_json5.safetensors",
    )


if __name__ == "__main__":
    """
    Replace paths with your appropriate paths.
    To run: python -m moondream.finetune.finetune_text
    """
    main()
